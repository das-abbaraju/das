Version 2: Reimplementation of version 1, using Angular.js instead of jQuery.
