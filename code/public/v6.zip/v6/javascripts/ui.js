var app = angular.module('peopleApp', ['util']);

app.controller('TopCtrl', function($scope) {

  $scope.editingPerson = null;

  $scope.editing = function() {
    return $scope.editingPerson != null;
  }

  $scope.startEdit = function(person) {
    $scope.editingPerson = person;
  }

  $scope.stopEdit = function() {
    $scope.editingPerson = null;
  }
});

app.controller('PeopleSearchCtrl', function ($scope, psHttp) {
  $scope.searchPrefix = "";
  $scope.people       = [];
  $scope.predicate    = 'last';
  $scope.reverse      = false;

  $scope.checkSearch = function() {
    var value = $scope.searchPrefix ? $scope.searchPrefix : ""
    if (value.length < 2) {
      $scope.people = [];
    }
    else {
      search(value);
    }
  }    

  $scope.toggleSortOrder = function(column) {
    if (column == $scope.predicate) {
      // User clicked on the same column that's already being used to sort.
      // Reverse the sort.
      $scope.reverse = !$scope.reverse;
    }
    else {
      // User clicked on a different column. Sort in ascending order.
      $scope.predicate = column;
      $scope.reverse = false;
    }
  }

  $scope.hideWarning = function() {
    $scope.warning = null;
  }

  search = function(prefix) {
    var url = "/people/" + prefix;

    psHttp.get(url, function(data) {
      // end-excerpt search
      for (var i = 0; i < data.people.length; i++) {
        var p = data.people[i];
        p.birthDate = new Date(p.birthDate);
        p.name = p.first + " " + p.last;
      }
      $scope.people = data.people;
    });
  }
});

app.controller('EditCtrl', function ($scope, psHttp) {
  $scope.genders = { 'F': 'female', 'M': 'male' }

  $scope.cancelEdit = function() {
    $scope.stopEdit();
  }
});

app.controller('AlertCtrl', function ($scope, $rootScope, $timeout) {
  $rootScope.modalAlert = null;

  $rootScope.$watch("modalAlert", function(newValue) {
    if (newValue != null)
      $("#alert-modal").modal('show');
    else
      $("#alert-modal").modal('hide');
  });

  $scope.closeModal = function() {
    $rootScope.modalAlert = null;
  }
});
