# Code for Angular course

## Basic Layout

* `app.js` is the Node.js Express application, implementing a simple web
  and REST server.
  
* Under the `views`
