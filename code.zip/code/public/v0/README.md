Version of People Server search, implemented entirely in jQuery.
